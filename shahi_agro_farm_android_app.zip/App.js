import React, { useMemo, useState } from 'react';
import {
  SafeAreaView, ScrollView, View, Text, TouchableOpacity, TextInput,
  ImageBackground, StatusBar, Alert, StyleSheet
} from 'react-native';

const GREEN = '#145B3B';
const DARK = '#103B2A';
const LIGHT = '#F4F7E9';
const PALE = '#E7EEDB';
const MUTED = '#66756A';
const PRICE = 350;
const MIN_QTY = 20;
const MAX_QTY = 400;

function Btn({ title, onPress, secondary = false }) {
  return <TouchableOpacity onPress={onPress} style={[styles.btn, secondary && styles.btnSecondary]}>
    <Text style={[styles.btnText, secondary && styles.btnSecondaryText]}>{title}</Text>
  </TouchableOpacity>;
}
function Field({ label, value, onChangeText, placeholder, keyboardType = 'default', multiline = false }) {
  return <View style={styles.field}>
    <Text style={styles.label}>{label}</Text>
    <TextInput value={value} onChangeText={onChangeText} placeholder={placeholder}
      placeholderTextColor="#87938A" keyboardType={keyboardType} multiline={multiline}
      style={[styles.input, multiline && { minHeight: 76, textAlignVertical: 'top' }]} />
  </View>;
}

export default function App() {
  const [page, setPage] = useState('Home');
  const [qty, setQty] = useState('20');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [payment, setPayment] = useState('Cash on Delivery');
  const [bkash, setBkash] = useState('');
  const [nagad, setNagad] = useState('');
  const [trx, setTrx] = useState('');
  const [orders, setOrders] = useState([]);
  const [trackInput, setTrackInput] = useState('');
  const [lang, setLang] = useState('English');
  const [dark, setDark] = useState(false);

  const quantity = Math.max(0, parseInt(qty || '0', 10) || 0);
  const total = quantity * PRICE;
  const bg = dark ? '#101A14' : LIGHT;
  const card = dark ? '#1C2B21' : '#FFFFFF';
  const fg = dark ? '#F2F6EF' : DARK;
  const sub = dark ? '#BDCCBF' : MUTED;
  const bn = lang === 'বাংলা';
  const t = (en, bangla) => bn ? bangla : en;

  const createOrder = () => {
    if (!name.trim() || !phone.trim() || !address.trim()) {
      Alert.alert('Missing information', 'Please enter your name, phone number and delivery address.');
      return;
    }
    if (quantity < MIN_QTY || quantity > MAX_QTY) {
      Alert.alert('Quantity rule', `Order between ${MIN_QTY} and ${MAX_QTY} packets.`);
      return;
    }
    if (payment === 'bKash' && (!bkash.trim() || !trx.trim())) {
      Alert.alert('Payment details required', 'Enter your bKash number and transaction ID.');
      return;
    }
    if (payment === 'Nagad' && (!nagad.trim() || !trx.trim())) {
      Alert.alert('Payment details required', 'Enter your Nagad number and transaction ID.');
      return;
    }
    const code = 'SAF' + Math.random().toString(36).slice(2, 8).toUpperCase();
    const order = { code, name, phone, address, payment, qty: quantity, total, trx, status: payment === 'Cash on Delivery' ? 'Pending confirmation' : 'Awaiting payment verification' };
    setOrders(prev => [order, ...prev]);
    setTrackInput(code);
    setPage('Tracking');
    Alert.alert('Order request saved', `Your demo tracking code is ${code}. Digital payments still require verification by SHAHI AGRO FARM.`);
  };

  const shownOrder = useMemo(() => orders.find(o => o.code.toLowerCase() === trackInput.trim().toLowerCase()), [orders, trackInput]);
  const nav = ['Home', 'Shop', 'Orders', 'About'];

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
      <StatusBar barStyle={dark ? 'light-content' : 'dark-content'} />
      <View style={[styles.header, { backgroundColor: card }]}>
        <View style={styles.logo}><Text style={styles.logoMark}>SA</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.brand, { color: fg }]}>SHAHI AGRO FARM</Text>
          <Text style={[styles.tagline, { color: sub }]}>{t('Pure Feed • Healthy Life', 'বিশুদ্ধ খাদ্য • সুস্থ জীবন')}</Text>
        </View>
        <TouchableOpacity onPress={() => setPage('Settings')} style={styles.roundIcon}><Text style={{color: GREEN, fontSize: 18}}>⚙</Text></TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        {page === 'Home' && <>
          <View style={styles.hero}>
            <Text style={styles.eyebrow}>{t('NATURAL FEED  •  FARM DIRECT', 'প্রাকৃতিক খাদ্য • সরাসরি খামার থেকে')}</Text>
            <Text style={styles.heroTitle}>{t('Better Feed.', 'উন্নত পশুখাদ্য।')}{'\n'}{t('Healthier Herd.', 'সুস্থ গবাদিপশু।')}</Text>
            <Text style={styles.heroText}>{t('Nutritious grass silage for dairy farms, made for reliable feeding through the year.', 'সারা বছর নির্ভরযোগ্য পশুখাদ্যের জন্য পুষ্টিকর ঘাসের সাইলেজ।')}</Text>
            <View style={styles.grassArt}><Text style={{fontSize:54}}>🌱</Text><Text style={{fontSize:44}}>🐄</Text></View>
          </View>
          <View style={[styles.productCard, { backgroundColor: card }]}>
            <View style={styles.productVisual}><Text style={{fontSize:52}}>🌿</Text><Text style={styles.packText}>50 KG</Text></View>
            <View style={{ flex: 1 }}>
              <Text style={styles.pill}>BEST SELLER</Text>
              <Text style={[styles.productTitle, { color: fg }]}>SHAHI GRASS SILAGE</Text>
              <Text style={{color: sub}}>50 kg packet</Text>
              <Text style={styles.price}>৳350 <Text style={styles.each}>/ packet</Text></Text>
              <Btn title="Order Now →" onPress={() => setPage('Shop')} />
            </View>
          </View>
          <Text style={[styles.sectionTitle, {color: fg}]}>{t('Why choose our silage?', 'আমাদের সাইলেজ কেন?')}</Text>
          <View style={styles.benefits}>
            {['Good fiber supports rumen function and digestion','Fermentation helps preserve nutrients','Year-round feed during grass shortages','Convenient portioning for daily feeding'].map((x,i)=>
              <View key={x} style={styles.benefit}><Text style={styles.benefitIcon}>{['🌾','♻️','☀️','✓'][i]}</Text><Text style={[styles.benefitText,{color:fg}]}>{x}</Text></View>)}
          </View>
          <View style={styles.note}><Text style={{color: sub, lineHeight: 20}}>Feed results vary with forage quality, storage and the animal’s complete ration. Introduce silage gradually and provide clean water.</Text></View>
        </>}
        {page === 'Shop' && <>
          <Text style={[styles.pageTitle,{color:fg}]}>{t('Order Grass Silage','ঘাসের সাইলেজ অর্ডার')}</Text>
          <View style={[styles.productCard,{backgroundColor:card}]}>
            <View style={styles.productVisual}><Text style={{fontSize:54}}>🌿</Text><Text style={styles.packText}>50 KG</Text></View>
            <View style={{flex:1}}><Text style={[styles.productTitle,{color:fg}]}>SHAHI GRASS SILAGE</Text><Text style={{color:sub}}>50 kg / packet</Text><Text style={styles.price}>৳350</Text></View>
          </View>
          <View style={[styles.formCard,{backgroundColor:card}]}>
            <Text style={[styles.sectionTitle,{color:fg}]}>Choose quantity</Text>
            <View style={styles.quantityRow}>
              <TouchableOpacity style={styles.qtyButton} onPress={()=>setQty(String(Math.max(MIN_QTY,quantity-1)))}><Text style={styles.qtyButtonText}>−</Text></TouchableOpacity>
              <TextInput style={[styles.qtyInput,{color:fg}]} keyboardType="number-pad" value={qty} onChangeText={setQty}/>
              <TouchableOpacity style={styles.qtyButton} onPress={()=>setQty(String(Math.min(MAX_QTY,quantity+1)))}><Text style={styles.qtyButtonText}>+</Text></TouchableOpacity>
            </View>
            <Text style={{color:sub,marginBottom:10}}>Minimum 20 packets • Maximum 400 packets</Text>
            <View style={styles.totalRow}><Text style={[styles.totalLabel,{color:fg}]}>Total weight</Text><Text style={[styles.totalValue,{color:fg}]}>{quantity*50} kg</Text></View>
            <View style={styles.totalRow}><Text style={[styles.totalLabel,{color:fg}]}>Product total</Text><Text style={styles.totalValue}>৳{total.toLocaleString('en-BD')}</Text></View>
            <Text style={[styles.label,{marginTop:18}]}>Customer details</Text>
            <Field label="Full name" value={name} onChangeText={setName} placeholder="Your name"/>
            <Field label="Phone number" value={phone} onChangeText={setPhone} placeholder="01XXXXXXXXX" keyboardType="phone-pad"/>
            <Field label="Delivery address" value={address} onChangeText={setAddress} placeholder="Village, upazila, district" multiline/>
            <Text style={[styles.sectionTitle,{color:fg,marginTop:8}]}>Payment method</Text>
            {['Cash on Delivery','bKash','Nagad'].map(m=><TouchableOpacity key={m} onPress={()=>setPayment(m)} style={[styles.paymentOption,payment===m&&styles.paymentSelected]}><View style={[styles.radio,payment===m&&styles.radioActive]}/><Text style={{color:fg,fontWeight:'600'}}>{m}</Text>{m==='bKash'&&<Text style={styles.payNumber}>01799900886</Text>}</TouchableOpacity>)}
            {payment==='bKash'&&<Field label="Your bKash number" value={bkash} onChangeText={setBkash} placeholder="Customer bKash number" keyboardType="phone-pad"/>}
            {payment==='Nagad'&&<Field label="Your Nagad number" value={nagad} onChangeText={setNagad} placeholder="Customer Nagad number" keyboardType="phone-pad"/>}
            {payment!=='Cash on Delivery'&&<Field label="Transaction ID (required)" value={trx} onChangeText={setTrx} placeholder="Enter payment transaction ID"/>}
            <View style={styles.note}><Text style={{color:sub,lineHeight:20}}>Digital payment transaction IDs are collected for manual verification. This demo does not connect to bKash/Nagad APIs and cannot independently confirm payment. Do not treat a submitted ID as verified.</Text></View>
            <Btn title="Submit Order Request" onPress={createOrder}/>
          </View>
        </>}
        {page === 'Orders' && <>
          <Text style={[styles.pageTitle,{color:fg}]}>Orders & Tracking</Text>
          <View style={[styles.formCard,{backgroundColor:card}]}>
            <Field label="Tracking code" value={trackInput} onChangeText={setTrackInput} placeholder="Enter SAF tracking code"/>
            <Btn title="Track order" onPress={()=>setPage('Tracking')}/>
          </View>
          {orders.length===0 ? <Text style={[styles.empty,{color:sub}]}>No orders saved on this device yet.</Text> : orders.map(o=><View key={o.code} style={[styles.orderCard,{backgroundColor:card}]}><Text style={styles.orderCode}>{o.code}</Text><Text style={{color:fg}}>{o.qty} packets • ৳{o.total.toLocaleString('en-BD')}</Text><Text style={{color:sub,marginTop:5}}>{o.status}</Text></View>)}
        </>}
        {page === 'Tracking' && <>
          <Text style={[styles.pageTitle,{color:fg}]}>Order Tracking</Text>
          <View style={[styles.formCard,{backgroundColor:card}]}>
            <Field label="Tracking code" value={trackInput} onChangeText={setTrackInput} placeholder="SAFXXXXXX"/>
            <Btn title="Find order" onPress={()=>{}}/>
            {shownOrder ? <View style={styles.trackResult}><Text style={styles.orderCode}>{shownOrder.code}</Text><Text style={[styles.productTitle,{color:fg}]}>{shownOrder.qty} packets • {shownOrder.qty*50} kg</Text><Text style={styles.price}>৳{shownOrder.total.toLocaleString('en-BD')}</Text><Text style={[styles.status,{color:GREEN}]}>{shownOrder.status}</Text><Text style={{color:sub,marginTop:8}}>Customer: {shownOrder.name}</Text></View> : <Text style={[styles.empty,{color:sub}]}>Enter a tracking code created on this device. Orders are stored locally in this demo; production tracking needs a secure backend.</Text>}
          </View>
        </>}
        {page === 'About' && <>
          <Text style={[styles.pageTitle,{color:fg}]}>About SHAHI AGRO FARM</Text>
          <View style={[styles.formCard,{backgroundColor:card}]}>
            <Text style={[styles.heroTitle,{fontSize:26,color:fg}]}>Pure Feed. Healthy Life.</Text>
            <Text style={[styles.bodyCopy,{color:sub}]}>SHAHI AGRO FARM is focused on practical farm products and quality agricultural feed. Our first featured product is SHAHI GRASS SILAGE, designed for convenient roughage management on dairy farms.</Text>
            <Text style={[styles.sectionTitle,{color:fg}]}>Contact us</Text>
            <Text style={[styles.bodyCopy,{color:sub}]}>01799900886{'\n'}01632638470{'\n'}Babul Chearman Bari, Char Bojlul Korim, Char Bata-3813, Subarnachar, Noakhali</Text>
            <Btn title="Open WhatsApp confirmation" onPress={()=>Alert.alert('WhatsApp contact','Message 01814026318 to confirm order details. Add WhatsApp deep-link integration for production.')}/>
          </View>
        </>}
        {page === 'Settings' && <>
          <Text style={[styles.pageTitle,{color:fg}]}>Settings</Text>
          <View style={[styles.formCard,{backgroundColor:card}]}>
            <Text style={[styles.sectionTitle,{color:fg}]}>Language</Text>
            <View style={styles.settingRow}><Btn title="English" secondary={lang!=='English'} onPress={()=>setLang('English')}/><Btn title="বাংলা" secondary={lang!=='বাংলা'} onPress={()=>setLang('বাংলা')}/></View>
            <Text style={[styles.sectionTitle,{color:fg,marginTop:20}]}>Appearance</Text>
            <View style={styles.settingRow}><Btn title="Light theme" secondary={!dark} onPress={()=>setDark(false)}/><Btn title="Dark theme" secondary={!dark} onPress={()=>setDark(true)}/></View>
            <Text style={[styles.noteText,{color:sub,marginTop:18}]}>Payment gateway, server-side order storage and live delivery updates must be configured before public launch.</Text>
          </View>
        </>}
      </ScrollView>
      <View style={[styles.nav,{backgroundColor:card,borderTopColor:dark?'#2D4033':'#E5EBDD'}]}>
        {nav.map((n,i)=><TouchableOpacity key={n} onPress={()=>setPage(n)} style={styles.navItem}><Text style={[styles.navIcon,{color:page===n?GREEN:sub}]}>{['⌂','▦','▤','◎'][i]}</Text><Text style={[styles.navText,{color:page===n?GREEN:sub,fontWeight:page===n?'700':'500'}]}>{n}</Text></TouchableOpacity>)}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1}, header:{paddingHorizontal:18,paddingVertical:12,flexDirection:'row',alignItems:'center',gap:10,borderBottomWidth:1,borderBottomColor:'#E8EDDF'},
  logo:{width:48,height:48,borderRadius:24,backgroundColor:GREEN,alignItems:'center',justifyContent:'center',borderWidth:3,borderColor:'#D8E4C7'},
  logoMark:{color:'#FFFBEF',fontWeight:'900',fontSize:15}, brand:{fontSize:15,fontWeight:'900',letterSpacing:.2},tagline:{fontSize:11,marginTop:3},roundIcon:{width:38,height:38,borderRadius:20,backgroundColor:PALE,alignItems:'center',justifyContent:'center'},
  content:{padding:16,paddingBottom:28},hero:{backgroundColor:'#E3EED7',borderRadius:24,padding:22,overflow:'hidden',minHeight:270},
  eyebrow:{fontSize:10,fontWeight:'800',letterSpacing:1.3,color:GREEN},heroTitle:{fontSize:32,fontWeight:'900',color:DARK,lineHeight:36,marginTop:12},heroText:{fontSize:14,lineHeight:21,color:'#395847',maxWidth:'90%',marginTop:8},
  grassArt:{marginTop:12,flexDirection:'row',justifyContent:'flex-end',alignItems:'center'},productCard:{marginTop:16,borderRadius:22,padding:12,flexDirection:'row',gap:12,shadowColor:'#123',shadowOpacity:.06,shadowRadius:12,elevation:2},
  productVisual:{width:112,minHeight:145,borderRadius:16,backgroundColor:'#E4EED7',alignItems:'center',justifyContent:'center'},packText:{color:GREEN,fontWeight:'900',fontSize:12,marginTop:4},pill:{alignSelf:'flex-start',backgroundColor:'#E2F0D5',color:GREEN,fontSize:9,fontWeight:'800',paddingHorizontal:9,paddingVertical:5,borderRadius:20,overflow:'hidden'},
  productTitle:{fontSize:15,fontWeight:'900',marginTop:7},price:{fontSize:24,fontWeight:'900',color:'#4B853A',marginTop:6},each:{fontSize:11,fontWeight:'500',color:MUTED},btn:{backgroundColor:GREEN,borderRadius:28,paddingVertical:13,paddingHorizontal:17,alignItems:'center',justifyContent:'center',marginTop:10,flex:1},btnText:{color:'#FFF',fontSize:13,fontWeight:'800'},btnSecondary:{backgroundColor:PALE,borderWidth:1,borderColor:'#C9D8BC'},btnSecondaryText:{color:GREEN},
  sectionTitle:{fontSize:18,fontWeight:'900',marginTop:22,marginBottom:12},benefits:{gap:9},benefit:{flexDirection:'row',alignItems:'center',backgroundColor:'#E9F0DF',padding:12,borderRadius:14,gap:12},benefitIcon:{fontSize:21},benefitText:{fontSize:13,flex:1,fontWeight:'600'},note:{backgroundColor:'#EEF2E7',padding:13,borderRadius:13,marginTop:14},pageTitle:{fontSize:27,fontWeight:'900',marginBottom:12},formCard:{padding:16,borderRadius:22,marginTop:8},quantityRow:{flexDirection:'row',alignItems:'center',gap:12,marginBottom:10},qtyButton:{width:44,height:44,borderRadius:22,backgroundColor:GREEN,alignItems:'center',justifyContent:'center'},qtyButtonText:{color:'white',fontSize:24,fontWeight:'700'},qtyInput:{fontSize:22,fontWeight:'900',minWidth:60,textAlign:'center',borderBottomWidth:1,borderBottomColor:'#C7D4C0',padding:5},totalRow:{flexDirection:'row',justifyContent:'space-between',paddingVertical:9,borderBottomWidth:1,borderBottomColor:'#E7EDE2'},totalLabel:{fontSize:14},totalValue:{fontSize:16,fontWeight:'900'},field:{marginTop:12},label:{fontSize:12,fontWeight:'800',color:GREEN,marginBottom:6},input:{backgroundColor:'#F7F9F3',borderWidth:1,borderColor:'#DDE6D6',borderRadius:12,paddingHorizontal:13,paddingVertical:12,color:'#183D2C',fontSize:14},paymentOption:{flexDirection:'row',alignItems:'center',gap:10,padding:13,borderRadius:12,borderWidth:1,borderColor:'#DDE6D6',marginTop:8},paymentSelected:{borderColor:GREEN,backgroundColor:'#EFF6E8'},radio:{width:17,height:17,borderRadius:10,borderWidth:1.5,borderColor:'#879B88'},radioActive:{backgroundColor:GREEN,borderColor:GREEN},payNumber:{marginLeft:'auto',fontSize:11,color:GREEN,fontWeight:'700'},empty:{fontSize:13,lineHeight:20,marginTop:16},orderCard:{padding:16,borderRadius:16,marginTop:10},orderCode:{fontSize:17,fontWeight:'900',color:GREEN},trackResult:{borderTopWidth:1,borderTopColor:'#E3EBDD',marginTop:18,paddingTop:16},status:{fontWeight:'800',marginTop:10},bodyCopy:{fontSize:14,lineHeight:23,marginTop:10},settingRow:{flexDirection:'row',gap:10},noteText:{fontSize:13,lineHeight:20},nav:{flexDirection:'row',justifyContent:'space-around',paddingTop:9,paddingBottom:10,borderTopWidth:1},navItem:{alignItems:'center',minWidth:56},navIcon:{fontSize:23,lineHeight:25},navText:{fontSize:10,marginTop:2}
});
